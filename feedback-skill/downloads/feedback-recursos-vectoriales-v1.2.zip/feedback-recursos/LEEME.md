# Recursos vectoriales Feedback · v1.2

Archivos SVG editables: flecha geométrica, retícula de portadilla y retícula de doce columnas.

**Colores**: coral #F04D51, cian #0BB0D2, negro #111111 y blanco.

Las tipografías comerciales y el logotipo Feedback **no están incluidos**.
Los SVG son plantillas demostrativas; sustitúyelos o adáptalos a cada encargo.
Para tablas y datos auténticos, preservar valores originales sin alterarlos.

Política de uso de la marca: consultar https://maxiandradeps4-blip.github.io/visual1/feedback-skill/USO-Y-LICENCIAS.md
